package com.example.airjordanhistory;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class TelaAJ1 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_aj1);
    }
}