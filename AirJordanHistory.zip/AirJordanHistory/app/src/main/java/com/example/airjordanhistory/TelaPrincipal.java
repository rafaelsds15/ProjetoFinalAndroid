package com.example.airjordanhistory;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class TelaPrincipal extends AppCompatActivity {

    Button botaoAJ1,botaoAJ3,botaoAJ4,botaoAJ5,botaoAJ6,botaoAJ9;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_principal);


        botaoAJ1=findViewById(R.id.button2);
        botaoAJ1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getApplicationContext(),TelaAJ1.class);
                startActivity(intent);
            }
        });



        botaoAJ3=findViewById(R.id.button3);
        botaoAJ3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getApplicationContext(),TelaAJ3.class);
                startActivity(intent);
            }
        });

        botaoAJ4=findViewById(R.id.button4);
        botaoAJ4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getApplicationContext(),TelaAJ4.class);
                startActivity(intent);
            }
        });


        botaoAJ5=findViewById(R.id.button5);
        botaoAJ5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getApplicationContext(),TelaAJ5.class);
                startActivity(intent);
            }
        });

        botaoAJ6=findViewById(R.id.button6);
        botaoAJ6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getApplicationContext(),TelaAJ6.class);
                startActivity(intent);
            }
        });

        botaoAJ9=findViewById(R.id.button7);
        botaoAJ9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getApplicationContext(),TelaAJ9.class);
                startActivity(intent);
            }
        });

    }
}